size_t strnlen (const char *string, size_t maxlen);
