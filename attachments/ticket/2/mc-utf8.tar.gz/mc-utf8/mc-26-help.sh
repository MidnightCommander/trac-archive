#!/bin/sh
ROOT=""
ENC="iso88591"

LN="es"
iconv -f $ENC -t utf-8 ${ROOT}doc/${LN}/mc.1.in -o ${ROOT}doc/${LN}/mc.1.in.utf8
mv ${ROOT}doc/${LN}/mc.1.in.utf8 ${ROOT}doc/${LN}/mc.1.in
iconv -f $ENC -t utf-8 ${ROOT}doc/${LN}/xnc.hlp -o ${ROOT}doc/${LN}/xnc.hlp.utf8
mv ${ROOT}doc/${LN}/xnc.hlp.utf8 ${ROOT}doc/${LN}/xnc.hlp

LN="it"
iconv -f $ENC -t utf-8 ${ROOT}doc/${LN}/mc.1.in -o ${ROOT}doc/${LN}/mc.1.in.utf8
mv ${ROOT}doc/${LN}/mc.1.in.utf8 ${ROOT}doc/${LN}/mc.1.in
iconv -f $ENC -t utf-8 ${ROOT}doc/${LN}/xnc.hlp -o ${ROOT}doc/${LN}/xnc.hlp.utf8
mv ${ROOT}doc/${LN}/xnc.hlp.utf8 ${ROOT}doc/${LN}/xnc.hlp

ENC="iso88592"

LN="hu"
iconv -f $ENC -t utf-8 ${ROOT}doc/${LN}/mc.1.in -o ${ROOT}doc/${LN}/mc.1.in.utf8
mv ${ROOT}doc/${LN}/mc.1.in.utf8 ${ROOT}doc/${LN}/mc.1.in
iconv -f $ENC -t utf-8 ${ROOT}doc/${LN}/xnc.hlp -o ${ROOT}doc/${LN}/xnc.hlp.utf8
mv ${ROOT}doc/${LN}/xnc.hlp.utf8 ${ROOT}doc/${LN}/xnc.hlp

LN="pl"
iconv -f $ENC -t utf-8 ${ROOT}doc/${LN}/mc.1.in -o ${ROOT}doc/${LN}/mc.1.in.utf8
mv ${ROOT}doc/${LN}/mc.1.in.utf8 ${ROOT}doc/${LN}/mc.1.in
iconv -f $ENC -t utf-8 ${ROOT}doc/${LN}/xnc.hlp -o ${ROOT}doc/${LN}/xnc.hlp.utf8
mv ${ROOT}doc/${LN}/xnc.hlp.utf8 ${ROOT}doc/${LN}/xnc.hlp

ENC="iso88595"

LN="sr"
iconv -f $ENC -t utf-8 ${ROOT}doc/${LN}/mc.1.in -o ${ROOT}doc/${LN}/mc.1.in.utf8
mv ${ROOT}doc/${LN}/mc.1.in.utf8 ${ROOT}doc/${LN}/mc.1.in
iconv -f $ENC -t utf-8 ${ROOT}doc/${LN}/xnc.hlp -o ${ROOT}doc/${LN}/xnc.hlp.utf8
mv ${ROOT}doc/${LN}/xnc.hlp.utf8 ${ROOT}doc/${LN}/xnc.hlp

ENC="koi8-r"

LN="ru"
iconv -f $ENC -t utf-8 ${ROOT}doc/${LN}/mc.1.in -o ${ROOT}doc/${LN}/mc.1.in.utf8
mv ${ROOT}doc/${LN}/mc.1.in.utf8 ${ROOT}doc/${LN}/mc.1.in
iconv -f $ENC -t utf-8 ${ROOT}doc/${LN}/xnc.hlp -o ${ROOT}doc/${LN}/xnc.hlp.utf8
mv ${ROOT}doc/${LN}/xnc.hlp.utf8 ${ROOT}doc/${LN}/xnc.hlp
