#!/bin/sh
ROOT=""

iconv -f iso88592 -t utf8 ${ROOT}lib/mc.hint.cs -o ${ROOT}lib/mc.hint.cs.utf8
mv ${ROOT}lib/mc.hint.cs.utf8 ${ROOT}lib/mc.hint.cs

iconv -f iso88592 -t utf8 ${ROOT}lib/mc.hint.hu -o ${ROOT}lib/mc.hint.hu.utf8
mv ${ROOT}lib/mc.hint.hu.utf8 ${ROOT}lib/mc.hint.hu

iconv -f iso88592 -t utf8 ${ROOT}lib/mc.hint.pl -o ${ROOT}lib/mc.hint.pl.utf8
mv ${ROOT}lib/mc.hint.pl.utf8 ${ROOT}lib/mc.hint.pl

iconv -f iso88591 -t utf8 ${ROOT}lib/mc.hint.es -o ${ROOT}lib/mc.hint.es.utf8
mv ${ROOT}lib/mc.hint.es.utf8 ${ROOT}lib/mc.hint.es

iconv -f iso88591 -t utf8 ${ROOT}lib/mc.hint.nl -o ${ROOT}lib/mc.hint.nl.utf8
mv ${ROOT}lib/mc.hint.nl.utf8 ${ROOT}lib/mc.hint.nl

iconv -f iso88591 -t utf8 ${ROOT}lib/mc.hint.it -o ${ROOT}lib/mc.hint.it.utf8
mv ${ROOT}lib/mc.hint.it.utf8 ${ROOT}lib/mc.hint.it

iconv -f iso88595 -t utf8 ${ROOT}lib/mc.hint.sr -o ${ROOT}lib/mc.hint.sr.utf8
mv ${ROOT}lib/mc.hint.sr.utf8 ${ROOT}lib/mc.hint.sr

iconv -f koi8-r -t utf8 ${ROOT}lib/mc.hint.ru -o ${ROOT}lib/mc.hint.ru.utf8
mv ${ROOT}lib/mc.hint.ru.utf8 ${ROOT}lib/mc.hint.ru

iconv -f koi8-u -t utf8 ${ROOT}lib/mc.hint.uk -o ${ROOT}lib/mc.hint.uk.utf8
mv ${ROOT}lib/mc.hint.uk.utf8 ${ROOT}lib/mc.hint.uk

iconv -f big5hkscs -t utf8 ${ROOT}lib/mc.hint.zh -o ${ROOT}lib/mc.hint.zh.utf8
mv ${ROOT}lib/mc.hint.zh.utf8 ${ROOT}lib/mc.hint.zh
