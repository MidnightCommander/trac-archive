#!/bin/sh

autopoint

aclocal -Im4

automake --add-missing

autoconf

